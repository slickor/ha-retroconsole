#!/bin/bash
# Installation script for HA RetroConsole

GAMEDIR=$(dirname "$0")
cd "$GAMEDIR"

echo "Creating virtual environment (this might take a minute)..."
python3 -m venv venv

if [ $? -ne 0 ]; then echo "Failed to create venv"; exit 1; fi

echo "Installing Python dependencies..."
# We use the pip inside the venv to ensure isolation
./venv/bin/python -m pip install --upgrade pip
if ./venv/bin/python -m pip install -r requirements.txt; then
    echo "Setup complete!"
    touch .installed
else
    echo "Installation failed. Check internet connection."
    exit 1
fi